package Assignment4;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class PracticeBlockingQueue {

    public static void main(String[] args){

    BlockingQueue<Integer> product_list = new ArrayBlockingQueue<>(5);

        Thread t1 = new Thread(new ProducerUsingArrayBlockingQueue(product_list));//producer

        Thread t2 = new Thread(new ConsumerUsingBlockingQueue(product_list)); // Consumer

        t1.start();
        t2.start();

    }
}
