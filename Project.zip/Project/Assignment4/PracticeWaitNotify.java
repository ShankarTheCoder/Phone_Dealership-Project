package Assignment4;
import java.util.*;
public class PracticeWaitNotify {

    public static void main(String[] args){
        List<Integer>product_list =new ArrayList<>();

        Thread t1 = new Thread(new ProducerUsingWaitNotify(product_list));

        Thread t12 = new Thread(new ConsumerUsingWaitNotify(product_list));

        t1.start();
        t12.start();

    }

}
