package Assignment4;

import java.util.List;

public class ConsumerUsingWaitNotify implements Runnable {

    List<Integer> product_list = null;
    int limit = 5;

    int product_n0;

    // Constructor
    public ConsumerUsingWaitNotify(List<Integer> product_list) {
        this.product_list = product_list;
    }

    public void TakeProduct() throws InterruptedException {

        synchronized (product_list) {

            while (product_list.isEmpty()) {
                System.out.println("No products to take!");
                product_list.wait();
            }



        }
        synchronized (product_list){
 
            Thread.sleep(1000);

            System.out.println("Taken product " + product_list.remove(0));

            product_list.notify();
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                TakeProduct();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}